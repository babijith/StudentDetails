<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?><!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Students Details</title>
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
	<script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
	<h1 class="text-center">Students Details</h1>
    <h2 id="message"><?php if($error){
    	foreach ($error as $key => $value) { ?>
    		<p><?=$value?></p>
    <?php	}
    }
    else if($success){ ?>
    	<p><?=$success ?></p>

    <?php }  ?></h2> 

	<div class="container-fluid ">
		<form name="dataupload" id='dataupload' method ="POST" action="<?php echo base_url();?>" enctype="multipart/form-data">
        <input type="hidden" class="base_url" value='<?php echo base_url();?>'>
		<input type="file" name ="csvFile" id="csvfile" accept=".csv">
		<input type ="button" name ="btn" value="Upload CSV" id ="csv_upld">
		<!-- <input type ="button" name ="btn1" value="Download PDF" id ="csv_upld"> -->
	</form>
<?php if($stud){ ?>
	<table class="table table-bordered  my-4">
		<thead>
			<tr><td>Name</td>
				<td>DOB</td>
				<td>Subject1</td>
				<td>Subject2</td>
				<td>Action</td>
			</tr>
		</thead>
		<tbody>
			<?php foreach ($stud as $key => $value) {?>
				
			<tr>
				<td> <?=$value['name']?></td>
				<td> <?=$value['dob']?></td>
				<td> <?=$value['sub1']?></td>
				<td> <?=$value['sub2']?></td>
				<td> <input type="button" class="btn btn-success download" value="Download" data-id="<?=$value['id']?>"></td>
		</tr>
			<?php }?>
		</tbody>
	</table>
<?php }?>
	</div>

	
</div>
<script>
$(document).ready(function() {
	var base_url = $('.base_url').val();
	$('#csv_upld').on('click',function(){
        var filename = $('#csvfile').val();
        if(filename !=''){
        	var ext = getExtension(filename);
        	if(ext == 'csv'){
                $('#dataupload').submit();
               // window.location = base_url;
        	}else{
        		alert('Invalid Format');
        	}
        }else{
           alert('Please Upload a Csv file');
        }
	});
	$('.download').on('click',function(){
		var id = $(this).attr('data-id');
		$.ajax({
	        url: base_url+'Students/download',
	        data: { id: id },
	        dataType: 'json', 
	        type: 'post',
	        success: function(data) {
	        	alert();
	            // response = jQuery.parseJSON(data);
	            // console.log(response);
	        }             
        });

	});
	 $("#message").fadeOut(8000);
});
function getExtension(filename) {
  var parts = filename.split('.');
  return parts[parts.length - 1];
}
</script>

</body>
</html>