<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Students extends CI_Controller {

	 function __construct() {
        parent::__construct();
        $this->load->library('session');
		$this->load->model('Student_model');
    }
	
	public function index(){
		$data['error'] = $data['success'] = '';
		if(!empty($_FILES['csvFile']['name'])){
			$config['upload_path'] = './uploads/';
	        $config['allowed_types'] = 'csv';
	        $new_name = time().$_FILES["csvFile"]['name'];
            $config['file_name'] = $new_name;
	        $this->load->library('upload', $config);
	         
	        if (!$this->upload->do_upload('csvFile')) {
	            $error = array('error' => $this->upload->display_errors());
	            
	        } else {
	        	$file = FCPATH.'/uploads/'.$new_name;
	        	$fp = fopen($file, "r");

				$count = -1;
				$error_ar = array();
				$c =0;
			    while($csv_line = fgetcsv($fp,1024))
		        {
		            $count++;
		            if($count == 0)
		            {
		                continue;
		            }
		            $studentData[] = $csv_line;
		            
		            if(preg_match_all('!\d+!', $csv_line[0]) || empty($csv_line[0])){
		            		
		            		$error_ar[$c] = 'Enter Name properly at row no:'.$count ;
		            		$c++;
		            	}
		            	if(!empty($csv_line[1])){

			            	$dob = $csv_line[1];
							$dob = date("Y-m-d", strtotime($dob));
							
							if($dob == '1970-01-01' || $dob == NULL){

								   $error_ar[$c] = 'Invalid Date format at row no:'.$count ;
				            		$c++;
							}
						}else{
							$error_ar[$c] = 'DOB required at row no:'.$count ;
			            	$c++;
						}
						 if(!is_numeric($csv_line[2])|| empty($csv_line[2])){
					 	$error_ar[$c] = 'Enter mark of subject1 properly at row no:'.$count ;
			             	$c++;
						 }
						 if(!is_numeric($csv_line[3])|| empty($csv_line[3])){
						 	$error_ar[$c] = "Enter mark subject2 properly at row no:".$count ;
			             		$c++;
						 }

		        }
		        if(!empty($error_ar)){
		        	$data['error']= $error_ar;
		        }else{
                    foreach ($studentData as $key => $value) {
                   	   $insertData = array(
		                'name' => $value[0] ,
		                'dob' => date('Y-m-d',strtotime($value[1])),
		                'sub1' => $value[2],
		                'sub2' => $value[3]
		               );
		               $this->db->insert('studentdata', $insertData);
                   }
                  
		        	$data['success'] = "Inserted Successfully";
		        }
		        fclose($fp) or die("can't close file");
		        unlink($file);
	        }
	        
		}
		$data['stud'] = $this->Student_model->readData();
		$this->load->view('students_view',$data);
    }
    public function download(){
    	$id = $this->input->post('id');
    	$data['error'] = $data['success'] = '';
    	$data['stud'] = $this->Student_model->readData($id);
    }
}